#pragma once

#include <string>

class gCs
{
public:
	static std::string gMessage;
};
