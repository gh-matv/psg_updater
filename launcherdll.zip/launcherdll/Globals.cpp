#include "pch.h"
#include "Globals.h"

boost::filesystem::path Globals::gamepath = ".";
std::string Globals::userkey = "";